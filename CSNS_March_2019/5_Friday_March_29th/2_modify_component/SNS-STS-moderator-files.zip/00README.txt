File Description:
------------------------
a1Gw2-2-f5.dat		- poisoned decoupled hydrogen moderator top upstream viewed in backward (Bl2)
a1Gw2-5-f5.dat		- coupled hydrogen moderator top downstream viewed (Bl5)
a1Gw2-8-f5.dat		- poisoned decoupled ambient water moderator bottom upstream viewed in forward (Bl8)
a1Gw2-11-f5.dat		- poisoned decoupled hydrogen moderator top upstream viewed in forward (Bl11)
a1Gw2-14-f5.dat		- coupled hydrogen moderator bottom downstream viewed (Bl14)
a1Gw2-17-f5.dat		- poisoned decoupled ambient water moderator bottom upstream viewed in backward (Bl17)
ver5tf2mm_sp.dat	- large cylindrical para-ydrogen moderator fed by STS mercury target
rot4m_sp.dat		- large cylindrical para-ydrogen moderator fed by STS rotating  target (reported at IWSMT9 - 3MW, 1.3GeV)
a1Gw2-2-f5_fit_fit.dat2	- fitting parameters to the above data
a1Gw2-5-f5_fit_fit.dat
a1Gw2-8-f5_fit_fit.dat
a1Gw2-11-f5_fit_fit.dat2
a1Gw2-14-f5_fit_fit.dat
a1Gw2-17-f5_fit_fit.dat
ver5tf2mm_sp_fit_fit.dat
rot4m_sp_fit_fit.dat
STS_moderator_performance.pdf - report about STS moderator performance fits
SNS_source4.pdf - report about SNS moderator performance fits and their use in the MCSTAS component SNS_source4.comp
SNS_source4.comp - MCSTAS source component utilizing spectral and Ikeda-Carpenter fitting parameter files
